"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import getStarfield from "@/public/three/getStarfield";
import { getFresnelMat } from "@/public/three/getFresnelMat";
import { FontLoader } from "node_modules/three/examples/jsm/loaders/FontLoader.js";
import { TextGeometry } from "node_modules/three/examples/jsm/geometries/TextGeometry.js";

export default function ThreeBackground() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 2.5, 10);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    ref.current!.appendChild(renderer.domElement);

    const earthGroup = new THREE.Group();
    scene.add(earthGroup);

    const loader = new THREE.TextureLoader();
    const geo = new THREE.IcosahedronGeometry(1, 12);

    const earth = new THREE.Mesh(
      geo,
      new THREE.MeshPhongMaterial({
        map: loader.load("/textures/00_earthmap1k.jpg"),
        bumpMap: loader.load("/textures/01_earthbump1k.jpg"),
        bumpScale: 0.04,
      })
    );
    earthGroup.add(earth);

    earthGroup.add(new THREE.Mesh(geo, getFresnelMat()));
    scene.add(getStarfield({ numStars: 2000 }));

    new FontLoader().load("/fonts/helvetiker_bold.typeface.json", font => {
      const text = new TextGeometry("SKILLXCHANGE", { font, size: 1.6, height: 0.05 });
      text.center();
      const mesh = new THREE.Mesh(text, new THREE.MeshBasicMaterial({ color: 0x3f7cff }));
      mesh.position.set(0, 2.2, -2);
      scene.add(mesh);
    });

    const light = new THREE.DirectionalLight(0xffffff, 2);
    light.position.set(-2, 0.5, 1.5);
    scene.add(light);

    const animate = () => {
      earth.rotation.y += 0.001;
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };
    animate();

    return () => renderer.dispose();
  }, []);

  return <div ref={ref} className="fixed inset-0 -z-10" />;
}
